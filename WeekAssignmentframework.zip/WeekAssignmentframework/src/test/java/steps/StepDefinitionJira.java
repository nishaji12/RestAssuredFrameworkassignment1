package steps;

import org.hamcrest.Matchers;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinitionJira {
	public static Response response;	
	public static RequestSpecification inputRequest;
	public static String id;
	
//	@Given("the issue is created with endpoint")
//	public void setUrl()
//	{
//		RestAssured.baseURI="https://cts622163.atlassian.net/rest/api/2/";
//	}
//	
//	@And("the auth is created")
//	public void Set()
//	{
//		RestAssured.authentication=RestAssured.preemptive().basic("jlavanyajeganathan17@gmail.com", "ATATT3xFfGF0rPpEFBZzBAojzBtZ1mZlhwVgLTnetLF9DHaPvcLpx-5KW1S7Q6EpBBGCAnlk81hQxlhchG6aQw-i9FtfTCv4OS07v-FjOoWT1454CBJ9bE51SRf_UMkWewpVx-CCLf7ymVhoxjc7Ic5jbtkcyOmJ3dHuxvGPDoHFeK0Uw6Kfb0Y=4D26F165");
//	}
	
	@When("the issue is created with string body {string}")
	public void issuecreated(String body)
	{
		inputRequest= RestAssured.given().contentType("application/json").given().body(body);
		response=inputRequest.post("issue");
		id = response.jsonPath().get("id");
		response.prettyPrint();
	}
	
	@When("the issue is updated with the string body as {string}")
	public void updateissue(String body) {
		RestAssured.given().contentType("application/json").given().body(body);
		response=inputRequest.put("issue/"+id);
		response.prettyPrint();
	}
	@When("the issue is deleted")
	public void deleteIssue()
	{
		response=inputRequest.delete("issue/"+id);
		response.prettyPrint();
	}
	
	@Then("validate the response code is {int}")
	public void validateStatusCode(int statuscode)
	 {
		 response.then().assertThat().statusCode(Matchers.equalTo(statuscode));
	 }

}
