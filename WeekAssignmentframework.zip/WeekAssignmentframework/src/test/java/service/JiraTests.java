package service;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static org.hamcrest.Matchers.*;

public class JiraTests extends BaseRequest{
		
	@Test
	public void getIssue(){
	  RestAssured.given()
			.get("issue")
			.then()
			.assertThat()
			.statusCode(201)
			.body(containsString("id"))
			.extract().response();
				
	}
	
	@Test
	public void createIssue(){
		RestAssured.given()	.contentType("application/json").when()	
		.body("{\r\n"
				+ "    \"fields\": {\r\n"
				+ "    \"project\":\r\n"
				+ "                {\r\n"
				+ "                    \"key\": \"SCRUM\"\r\n"
				+ "                },\r\n"
				+ "    \"summary\": \"create issue in RA project\",\r\n"
				+ "    \"description\": \"Creating of an issue using project keys and issue type names using the REST API\",\r\n"
				+ "    \"issuetype\": {\r\n"
				+ "                    \"name\": \"Bug\"\r\n"
				+ "                }\r\n"
				+ "    }\r\n"
				+ "}\r\n"
				+ "")
			.post("issue")
			.then()
			.assertThat()
			.statusCode(201)
			.body(containsString("id"));		
	}
	
	@Test
	public void updateIssue() {
		
		RestAssured.given()	.contentType("application/json").when()	
		.body("{\r\n"
				+ "    \"fields\": {\r\n"
				+ "\r\n"
				+ "        \"description\": \"Bug creation Using REST API for testing\"\r\n"
				+ "    }\r\n"
				+ "}\r\n"
				+ "")
		.put("issue/id")
		.then()
		.assertThat()
		.statusCode(404);
		
	}
	@Test
	public void deleteIssue() {
		RestAssured
		.delete("issue/id")
		.then()
		.assertThat()
		.statusCode(404);
	}
	
	
	
	@Test
	public void getAllIncidents() {
		
		RestAssured.given().queryParam("sysparm_fields", "sys_id,number")
		.get("incident")
		.then()
		.assertThat()
		.statusCode(200);
	}
	
	
}
